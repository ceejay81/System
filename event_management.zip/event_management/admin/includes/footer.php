</div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->

    <!-- Main Footer -->
    <footer class="main-footer">
        <!-- To the right -->
        <div class="float-right d-none d-sm-inline">
        Powered by <strong>JUSTINE BALASA ESPIRITU</strong>
        </div>
        <!-- Default to the left -->
        <strong>&copy; 2024 Event Management</strong> All rights reserved.
    </footer>
</div>
<!-- ./wrapper -->

<!-- AdminLTE Script -->
<script src="../adminlte/js/adminlte.min.js"></script>
<!-- Additional Scripts if needed -->

</body>
</html>
