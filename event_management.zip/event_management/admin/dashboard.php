<?php
// Start session
session_start();

// Check if the user is logged in as teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../auth/login.php');
    exit;
}

// Include necessary files
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Fetch admin details from database
$user_id = $_SESSION['user_id'];
$user = getUserById($user_id);
// Check if user exists
if (!$user) {
    die('User not found.'); // Handle error appropriately
}

// Fetch events (ensure this function is defined and returns an array)
$events = getAllEvents();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="../adminlte/css/adminlte.min.css">
    <!-- Additional CSS if needed -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <?php require_once 'includes/header.php'; ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Admin Dashboard</h1>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Page content goes here -->
                <div class="row">
                    <div class="col-md-12">
                        <h3>Events</h3>
                        <ul>
                            <?php if (!empty($events)) : ?>
                                <?php foreach ($events as $event): ?>
                                    <li>
                                        <?php echo htmlspecialchars($event['event_name']); ?>
                                        <ul>
                                            <li>Date: <?php echo htmlspecialchars($event['event_date']); ?></li>
                                            <li>Location: <?php echo htmlspecialchars($event['event_location']); ?></li>
                                            <li>
                                                <a href="edit_event.php?event_id=<?php echo $event['event_id']; ?>">Edit Event</a>
                                            </li>
                                            <li>
                                                <a href="../qr_codes/generate_qr.php?event_id=<?php echo $event['event_id']; ?>">Generate QR Code</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <li>No events found.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Main Footer -->
    <footer class="main-footer">
        <div class="float-right d-none d-sm-inline">
        Powered by <strong>JUSTINE BALASA ESPIRITU</strong>
        </div>
        <strong>&copy; 2024 Event Management</strong> All rights reserved.
    </footer>
</div>
<!-- ./wrapper -->

<!-- AdminLTE Script -->
<script src="../adminlte/js/adminlte.min.js"></script>
<!-- Additional Scripts if needed -->
<script src="../js/scripts.js"></script>

</body>
</html>
